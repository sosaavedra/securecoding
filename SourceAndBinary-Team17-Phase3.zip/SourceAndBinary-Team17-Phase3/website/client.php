<?php

class Client extends Person{}

?>
