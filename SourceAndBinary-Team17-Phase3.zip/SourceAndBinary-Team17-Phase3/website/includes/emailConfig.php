<?php

define ( "SYSTEM_EMAIL_ID", "scteam17@gmail.com" );
define ( "EMAIL_SMTP", "smtp.gmail.com" );
define ( "EMAIL_PORT", "465" );
define ( "EMAIL_FROM", "Secure Banking" );
define ( "EMAIL_HEADER", "IMP:CONFIDENTIAL: secure banking" );
define ( "EMAIL_PASSWORD", "samurai17" );

?>
