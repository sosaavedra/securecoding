<?php

define("BANKSYS_HOST", "localhost");
define("BANKSYS_USER", "webuser");
define("BANKSYS_PWD", "kubruf#eGa4e");
define("BANKSYS_DB", "banksys");

?>
