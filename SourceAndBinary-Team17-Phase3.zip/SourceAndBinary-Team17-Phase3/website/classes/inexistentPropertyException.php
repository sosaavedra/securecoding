<?php

class InexistentPropertyException extends Exception{}

?>
