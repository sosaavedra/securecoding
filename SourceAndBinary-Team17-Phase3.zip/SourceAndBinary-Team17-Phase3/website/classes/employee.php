<?php

require_once "person.php";

class Employee extends Person{}

?>
