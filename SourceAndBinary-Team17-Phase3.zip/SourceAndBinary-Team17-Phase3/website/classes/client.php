<?php

class Client extends Person{
    protected $account_number;
    protected $balance;
}
?>
